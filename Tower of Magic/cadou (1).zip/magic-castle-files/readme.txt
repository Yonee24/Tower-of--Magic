Magic Castle Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.

The downloadable file contains everything you need to start working right away on your project. I have included the PSD and the cut out Tiles Sets in PNG file format.

- Contents

-- Layers Folder: Contains the ready to use PNG files for the loop-able background and tile set, the Sprites for ornaments and the sprites for the water and fire animation.

-- PSD Folder: Contains the Working PSD file in case you need to make changes.

-- Previews: examples on how the files should look. 


Thanks Again

Visit my site for free resources at ansimuz.com